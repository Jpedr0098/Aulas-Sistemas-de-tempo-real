#include <Arduino.h>

static const int LED_PIN = 2;
bool led = false;
unsigned long last = 0;
unsigned long lastPrint = 0;

//Tarefa 1 - Pisca Pisca c/ LED a cada 500ms
void blink_led(){
  unsigned long now = millis(); // millis pega variações apartir de 1 ms (mundo ideal)
  if(now - last >= 500){
    if(led == false){
      digitalWrite(LED_PIN, led);
      led = true;
    } else {
      digitalWrite(LED_PIN, led);
      led = false;
    }
    Serial.printf("[millies] periodo = %lu ms\n", (now - last));
    last = now;
  }
}

// Tarefa 2 - Processa alguma coisa ai...
void process_anything(){
  unsigned long temp0 = micros();
  for (volatile long i=0; i<50000; i++){} 
  // varialvel volatil: ela em sistemas embarcados descreve registradores 
  // Ela atualiza a variavel fora de contexto "lembre-se dessa fala da aula Guru", ou seja ele atualiza a variavel em uma linha sem que o ponteiro precise ir para a memoria e ler
  // Ela trata com entradas e saidas diretos do hardware (nivel de memoria ram)
  unsigned long temp1 = micros() - temp0;
  if(millis() - lastPrint >= 2000){
    lastPrint = millis();
    Serial.printf("[micros] periodo = %lu us\n",temp1);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  blink_led();
  process_anything();
}
